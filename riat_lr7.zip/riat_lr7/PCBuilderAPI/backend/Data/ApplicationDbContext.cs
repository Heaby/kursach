// Data/ApplicationDbContext.cs
using Microsoft.EntityFrameworkCore;
using PCBuilderAPI.Models;

namespace PCBuilderAPI.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Component> Components { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<PCBuild> PCBuilds { get; set; }
        public DbSet<Participant> Participants { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            
            // Конфигурация для Component
            modelBuilder.Entity<Component>(entity =>
            {
                entity.Property(e => e.Price)
                    .HasPrecision(10, 2);
                
                entity.Property(e => e.Rating)
                    .HasPrecision(3, 2);
                
                entity.HasOne(e => e.Category)
                    .WithMany(c => c.Components)
                    .HasForeignKey(e => e.CategoryId)
                    .OnDelete(DeleteBehavior.Restrict);
            });
            
            // Конфигурация для PCBuild
            modelBuilder.Entity<PCBuild>(entity =>
            {
                entity.Property(e => e.Price)
                    .HasPrecision(10, 2);
                
                entity.Property(e => e.Rating)
                    .HasPrecision(3, 2);
            });

            // Конфигурация для Participant
            modelBuilder.Entity<Participant>(entity =>
            {
                entity.HasIndex(e => e.Email)
                      .IsUnique();
            });
        }
    }
}