using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace PCBuilderAPI.Models
{
    public class PCBuild
    {
        [Key]
        [JsonPropertyName("id")]
        public int Id { get; set; }
        
        [Required]
        [StringLength(200)]
        [JsonPropertyName("name")]
        public string Name { get; set; } = string.Empty;
        
        [StringLength(50)]
        [JsonPropertyName("type")]
        public string Type { get; set; } = string.Empty; // gaming, work, budget
        
        [StringLength(500)]
        [JsonPropertyName("specs")]
        public string? Specs { get; set; }
        
        [Column(TypeName = "decimal(10, 2)")]
        [JsonPropertyName("price")]
        public decimal Price { get; set; }
        
        [JsonPropertyName("description")]
        public string? Description { get; set; }
        
        [StringLength(500)]
        [JsonPropertyName("imageUrl")]
        public string? ImageUrl { get; set; }
        
        [Column(TypeName = "decimal(3, 2)")]
        [JsonPropertyName("rating")]
        public decimal? Rating { get; set; }
        
        [JsonPropertyName("reviewCount")]
        public int ReviewCount { get; set; }
        
        [JsonPropertyName("stockQuantity")]
        public int StockQuantity { get; set; }
        
        [JsonPropertyName("createdAt")]
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}
