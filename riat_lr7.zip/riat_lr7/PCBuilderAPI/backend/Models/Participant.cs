using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace PCBuilderAPI.Models
{
    public class Participant
    {
        [Key]
        [JsonPropertyName("id")]
        public int Id { get; set; }

        [Required]
        [StringLength(150)]
        [JsonPropertyName("name")]
        public string Name { get; set; } = string.Empty;

        [Required]
        [StringLength(200)]
        [EmailAddress]
        [JsonPropertyName("email")]
        public string Email { get; set; } = string.Empty;

        // Храним хэш пароля, а не исходный пароль
        [Required]
        [StringLength(500)]
        public string PasswordHash { get; set; } = string.Empty;

        [JsonPropertyName("createdAt")]
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}

