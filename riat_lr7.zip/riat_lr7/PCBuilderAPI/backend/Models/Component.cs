// Models/Component.cs
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace PCBuilderAPI.Models
{
    public class Component
    {
        [Key]
        [JsonPropertyName("id")]
        public int Id { get; set; }
        
        [Required]
        [StringLength(200)]
        [JsonPropertyName("name")]
        public string Name { get; set; } = string.Empty;
        
        [StringLength(100)]
        [JsonPropertyName("model")]
        public string? Model { get; set; }
        
        [StringLength(100)]
        [JsonPropertyName("brand")]
        public string? Brand { get; set; }
        
        [JsonPropertyName("categoryId")]
        public int CategoryId { get; set; }
        
        [ForeignKey("CategoryId")]
        [JsonPropertyName("category")]
        public Category? Category { get; set; }
        
        [Column(TypeName = "decimal(10, 2)")]
        [JsonPropertyName("price")]
        public decimal Price { get; set; }
        
        [JsonPropertyName("stockQuantity")]
        public int StockQuantity { get; set; }
        
        [JsonPropertyName("description")]
        public string? Description { get; set; }
        
        [StringLength(500)]
        [JsonPropertyName("imageUrl")]
        public string? ImageUrl { get; set; }
        
        [Column(TypeName = "decimal(3, 2)")]
        [JsonPropertyName("rating")]
        public decimal? Rating { get; set; }
        
        [JsonPropertyName("reviewCount")]
        public int ReviewCount { get; set; }
        
        [JsonPropertyName("createdAt")]
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }

    public class Category
    {
        [Key]
        [JsonPropertyName("id")]
        public int Id { get; set; }
        
        [Required]
        [StringLength(100)]
        [JsonPropertyName("name")]
        public string Name { get; set; } = string.Empty;
        
        [StringLength(500)]
        [JsonPropertyName("description")]
        public string? Description { get; set; }
        
        [JsonIgnore]
        public ICollection<Component>? Components { get; set; }
    }
}