using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PCBuilderAPI.Data;
using PCBuilderAPI.Models;
using PCBuilderAPI.Services;

namespace PCBuilderAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public AuthController(ApplicationDbContext context)
        {
            _context = context;
        }

        public record RegisterRequest(string Name, string Email, string Password);
        public record LoginRequest(string Email, string Password);

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] RegisterRequest request)
        {
            if (string.IsNullOrWhiteSpace(request.Name) ||
                string.IsNullOrWhiteSpace(request.Email) ||
                string.IsNullOrWhiteSpace(request.Password))
            {
                return BadRequest("Имя, email и пароль обязательны.");
            }

            var normalizedEmail = request.Email.Trim().ToLowerInvariant();
            var exists = await _context.Participants.AnyAsync(u => u.Email == normalizedEmail);
            if (exists)
            {
                return Conflict("Пользователь с таким email уже зарегистрирован.");
            }

            var participant = new Participant
            {
                Name = request.Name.Trim(),
                Email = normalizedEmail,
                PasswordHash = PasswordHasher.Hash(request.Password)
            };

            _context.Participants.Add(participant);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(Register), new
            {
                participant.Id,
                participant.Name,
                participant.Email,
                participant.CreatedAt
            });
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginRequest request)
        {
            if (string.IsNullOrWhiteSpace(request.Email) ||
                string.IsNullOrWhiteSpace(request.Password))
            {
                return BadRequest("Email и пароль обязательны.");
            }

            var normalizedEmail = request.Email.Trim().ToLowerInvariant();
            var participant = await _context.Participants
                .FirstOrDefaultAsync(u => u.Email == normalizedEmail);

            if (participant == null || !PasswordHasher.Verify(request.Password, participant.PasswordHash))
            {
                return Unauthorized("Неверный email или пароль.");
            }

            return Ok(new
            {
                Message = "Вход выполнен успешно",
                Participant = new
                {
                    participant.Id,
                    participant.Name,
                    participant.Email
                }
            });
        }
    }
}

