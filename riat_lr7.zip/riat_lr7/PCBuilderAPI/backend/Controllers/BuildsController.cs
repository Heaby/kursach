using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PCBuilderAPI.Data;
using PCBuilderAPI.Models;

namespace PCBuilderAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BuildsController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public BuildsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: api/builds
        [HttpGet]
        public async Task<ActionResult<IEnumerable<object>>> GetBuilds(
            [FromQuery] string? type = null,
            [FromQuery] decimal? minPrice = null,
            [FromQuery] decimal? maxPrice = null,
            [FromQuery] string? search = null,
            [FromQuery] string? sortBy = "popularity",
            [FromQuery] int page = 1,
            [FromQuery] int pageSize = 12)
        {
            var query = _context.PCBuilds.AsQueryable();

            // Фильтрация по типу
            if (!string.IsNullOrEmpty(type))
            {
                query = query.Where(b => b.Type == type);
            }

            // Фильтрация по цене
            if (minPrice.HasValue)
            {
                query = query.Where(b => b.Price >= minPrice.Value);
            }

            if (maxPrice.HasValue)
            {
                query = query.Where(b => b.Price <= maxPrice.Value);
            }

            // Поиск по названию или описанию
            if (!string.IsNullOrEmpty(search))
            {
                query = query.Where(b => 
                    b.Name.Contains(search) || 
                    (b.Description != null && b.Description.Contains(search)));
            }

            // Сортировка
            query = sortBy?.ToLower() switch
            {
                "price_asc" => query.OrderBy(b => b.Price),
                "price_desc" => query.OrderByDescending(b => b.Price),
                "rating" => query.OrderByDescending(b => b.Rating),
                "newest" => query.OrderByDescending(b => b.CreatedAt),
                _ => query.OrderByDescending(b => b.ReviewCount) // По умолчанию по популярности
            };

            // Пагинация
            var totalCount = await query.CountAsync();
            var builds = await query
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            // Возвращаем результат с метаданными
            return Ok(new
            {
                TotalCount = totalCount,
                Page = page,
                PageSize = pageSize,
                TotalPages = (int)Math.Ceiling(totalCount / (double)pageSize),
                Data = builds
            });
        }

        // GET: api/builds/{id}
        [HttpGet("{id}")]
        public async Task<ActionResult<PCBuild>> GetBuild(int id)
        {
            var build = await _context.PCBuilds
                .FirstOrDefaultAsync(b => b.Id == id);

            if (build == null)
            {
                return NotFound();
            }

            return build;
        }

        // GET: api/builds/types
        [HttpGet("types")]
        public async Task<ActionResult<IEnumerable<string>>> GetBuildTypes()
        {
            var types = await _context.PCBuilds
                .Where(b => !string.IsNullOrEmpty(b.Type))
                .Select(b => b.Type!)
                .Distinct()
                .ToListAsync();

            return types;
        }
    }
}
