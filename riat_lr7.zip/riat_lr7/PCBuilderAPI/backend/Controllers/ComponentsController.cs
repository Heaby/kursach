// Controllers/ComponentsController.cs
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PCBuilderAPI.Data;
using PCBuilderAPI.Models;

namespace PCBuilderAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ComponentsController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public ComponentsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: api/components
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Component>>> GetComponents(
            [FromQuery] string? category = null,
            [FromQuery] string? brand = null,
            [FromQuery] decimal? minPrice = null,
            [FromQuery] decimal? maxPrice = null,
            [FromQuery] string? search = null,
            [FromQuery] string? sortBy = "popularity",
            [FromQuery] int page = 1,
            [FromQuery] int pageSize = 12)
        {
            var query = _context.Components
                .Include(c => c.Category)
                .AsQueryable();

            // Фильтрация по категории
            if (!string.IsNullOrEmpty(category))
            {
                query = query.Where(c => c.Category != null && c.Category.Name == category);
            }

            // Фильтрация по бренду
            if (!string.IsNullOrEmpty(brand))
            {
                query = query.Where(c => c.Brand == brand);
            }

            // Фильтрация по цене
            if (minPrice.HasValue)
            {
                query = query.Where(c => c.Price >= minPrice.Value);
            }

            if (maxPrice.HasValue)
            {
                query = query.Where(c => c.Price <= maxPrice.Value);
            }

            // Поиск по названию или модели
            if (!string.IsNullOrEmpty(search))
            {
                query = query.Where(c => 
                    c.Name.Contains(search) || 
                    (c.Model != null && c.Model.Contains(search)));
            }

            // Сортировка
            query = sortBy?.ToLower() switch
            {
                "price_asc" => query.OrderBy(c => c.Price),
                "price_desc" => query.OrderByDescending(c => c.Price),
                "rating" => query.OrderByDescending(c => c.Rating),
                "newest" => query.OrderByDescending(c => c.CreatedAt),
                _ => query.OrderByDescending(c => c.ReviewCount) // По умолчанию по популярности
            };

            // Пагинация
            var totalCount = await query.CountAsync();
            var components = await query
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            // Возвращаем результат с метаданными
            return Ok(new
            {
                TotalCount = totalCount,
                Page = page,
                PageSize = pageSize,
                TotalPages = (int)Math.Ceiling(totalCount / (double)pageSize),
                Data = components
            });
        }

        // GET: api/components/{id}
        [HttpGet("{id}")]
        public async Task<ActionResult<Component>> GetComponent(int id)
        {
            var component = await _context.Components
                .Include(c => c.Category)
                .FirstOrDefaultAsync(c => c.Id == id);

            if (component == null)
            {
                return NotFound();
            }

            return component;
        }

        // GET: api/components/categories
        [HttpGet("categories")]
        public async Task<ActionResult<IEnumerable<object>>> GetCategories()
        {
            var categories = await _context.Categories
                .Select(c => new
                {
                    Id = c.Id,
                    Name = c.Name,
                    Description = c.Description,
                    ComponentCount = _context.Components.Count(comp => comp.CategoryId == c.Id)
                })
                .ToListAsync();

            return Ok(categories);
        }

        // GET: api/components/brands
        [HttpGet("brands")]
        public async Task<ActionResult<IEnumerable<string>>> GetBrands()
        {
            var brands = await _context.Components
                .Where(c => !string.IsNullOrEmpty(c.Brand))
                .Select(c => c.Brand!)
                .Distinct()
                .ToListAsync();

            return brands;
        }
    }
}