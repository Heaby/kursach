using System.Security.Cryptography;
using System.Text;

namespace PCBuilderAPI.Services
{
    /// <summary>
    /// Простая утилита для хэширования паролей через SHA256.
    /// </summary>
    public static class PasswordHasher
    {
        public static string Hash(string password)
        {
            if (string.IsNullOrWhiteSpace(password))
            {
                return string.Empty;
            }

            using var sha = SHA256.Create();
            var bytes = Encoding.UTF8.GetBytes(password);
            var hash = sha.ComputeHash(bytes);
            return Convert.ToBase64String(hash);
        }

        public static bool Verify(string password, string hash)
        {
            if (string.IsNullOrWhiteSpace(hash))
            {
                return false;
            }

            return Hash(password) == hash;
        }
    }
}

