// Состояние приложения
const state = {
    filters: {
        type: null,
        minPrice: null,
        maxPrice: null,
        search: '',
        sortBy: 'popularity',
        page: 1,
        pageSize: 12
    },
    types: [],
    builds: [],
    totalCount: 0,
    totalPages: 1
};

// DOM элементы
const elements = {
    searchInput: document.getElementById('searchInput'),
    searchBtn: document.getElementById('searchBtn'),
    typeList: document.getElementById('typeList'),
    minPrice: document.getElementById('minPrice'),
    maxPrice: document.getElementById('maxPrice'),
    priceRange: document.getElementById('priceRange'),
    maxPriceLabel: document.getElementById('maxPriceLabel'),
    sortSelect: document.getElementById('sortSelect'),
    applyFilters: document.getElementById('applyFilters'),
    resetFilters: document.getElementById('resetFilters'),
    buildsGrid: document.getElementById('buildsGrid'),
    totalCount: document.getElementById('totalCount'),
    pagination: document.getElementById('pagination'),
    buildModal: document.getElementById('buildModal'),
    buildModalContent: document.getElementById('buildModalContent')
};

// Инициализация при загрузке страницы
document.addEventListener('DOMContentLoaded', async function() {
    console.log('Каталог сборок: Инициализация...');
    
    // Обновляем счетчик корзины
    updateCartCount();
    
    try {
        // Загружаем типы сборок
        await loadTypes();
        
        // Загружаем сборки
        await loadBuilds();
        
        // Инициализируем события
        initEvents();
        
        console.log('Каталог сборок: Инициализация завершена');
    } catch (error) {
        console.error('Ошибка инициализации:', error);
        showError('Не удалось загрузить данные. Пожалуйста, обновите страницу.');
    }
});

// Загрузка типов сборок
async function loadTypes() {
    try {
        const types = await fetchAPI(API_CONFIG.ENDPOINTS.BUILD_TYPES);
        state.types = types;
        renderTypes();
    } catch (error) {
        console.error('Ошибка загрузки типов:', error);
    }
}

// Загрузка сборок
async function loadBuilds() {
    try {
        elements.buildsGrid.innerHTML = `
            <div class="loading-products">
                <div class="spinner"></div>
                <p>Загрузка сборок...</p>
            </div>
        `;
        
        // Формируем параметры запроса
        const params = {};
        if (state.filters.type) params.type = state.filters.type;
        if (state.filters.minPrice) params.minPrice = state.filters.minPrice;
        if (state.filters.maxPrice) params.maxPrice = state.filters.maxPrice;
        if (state.filters.search) params.search = state.filters.search;
        if (state.filters.sortBy) params.sortBy = state.filters.sortBy;
        if (state.filters.page) params.page = state.filters.page;
        if (state.filters.pageSize) params.pageSize = state.filters.pageSize;
        
        const data = await fetchAPI(API_CONFIG.ENDPOINTS.BUILDS, params);
        
        // Сохраняем данные в состоянии
        state.builds = data.data || [];
        state.totalCount = data.totalCount || 0;
        state.totalPages = data.totalPages || 1;
        
        // Обновляем UI
        renderBuilds();
        renderPagination();
        updateStats();
        
    } catch (error) {
        console.error('Ошибка загрузки сборок:', error);
        elements.buildsGrid.innerHTML = `
            <div class="error-message">
                <i class="fas fa-exclamation-triangle"></i>
                <h3>Ошибка загрузки данных</h3>
                <p>Не удалось загрузить сборки. Пожалуйста, попробуйте позже.</p>
                <button class="btn btn-primary" onclick="loadBuilds()">
                    <i class="fas fa-redo"></i> Повторить попытку
                </button>
            </div>
        `;
    }
}

// Рендеринг типов
function renderTypes() {
    const container = elements.typeList;
    
    if (!state.types || state.types.length === 0) {
        container.innerHTML = '<div class="no-data">Типы не найдены</div>';
        return;
    }
    
    const typeLabels = {
        'gaming': 'Игровые',
        'work': 'Рабочие',
        'budget': 'Бюджетные'
    };
    
    const typesHTML = state.types.map(type => `
        <label class="type-item">
            <input type="radio" name="type" value="${type}" 
                   ${state.filters.type === type ? 'checked' : ''}>
            <span>${typeLabels[type] || type}</span>
        </label>
    `).join('');
    
    container.innerHTML = typesHTML + `
        <label class="type-item">
            <input type="radio" name="type" value="" ${!state.filters.type ? 'checked' : ''}>
            <span>Все типы</span>
        </label>
    `;
}

// Рендеринг сборок
function renderBuilds() {
    const container = elements.buildsGrid;
    
    if (!state.builds || state.builds.length === 0) {
        container.innerHTML = `
            <div class="no-builds">
                <i class="fas fa-search"></i>
                <h3>Сборки не найдены</h3>
                <p>Попробуйте изменить параметры фильтрации</p>
            </div>
        `;
        return;
    }
    
    const buildsHTML = state.builds.map(build => {
        // Определяем класс бейджа по типу
        let badgeClass = 'badge-gaming';
        let badgeText = 'Игровая';
        
        if (build.type === 'work') {
            badgeClass = 'badge-work';
            badgeText = 'Рабочая';
        } else if (build.type === 'budget') {
            badgeClass = 'badge-budget';
            badgeText = 'Бюджетная';
        }
        
        // Форматируем цену
        const formattedPrice = formatPrice(build.price);
        
        // Исправляем путь к изображению
        let imageUrl = build.imageUrl || 'https://via.placeholder.com/400x300?text=No+Image';
        if (imageUrl.startsWith('../public/images/')) {
            imageUrl = imageUrl.replace('../public/images/', '');
        }
        
        return `
            <div class="build-card" data-id="${build.id}">
                <div class="build-badge ${badgeClass}">${badgeText}</div>
                
                <div class="build-image-container" onclick="showBuildDetails(${build.id})">
                    <img src="${imageUrl}" 
                         alt="${build.name}"
                         class="build-image"
                         onerror="this.src='https://via.placeholder.com/400x300?text=Image+Error'">
                </div>
                
                <div class="build-content">
                    <div class="build-type">${getTypeLabel(build.type)}</div>
                    <h3 class="build-title" onclick="showBuildDetails(${build.id})">${build.name}</h3>
                    <div class="build-specs">${build.specs || 'Характеристики не указаны'}</div>
                    
                    <div class="build-price">${formattedPrice}</div>
                    
                    ${build.rating ? `
                    <div class="build-rating">
                        <div class="stars">
                            ${renderStars(build.rating)}
                        </div>
                        <span class="review-count">(${build.reviewCount || 0})</span>
                    </div>
                    ` : ''}
                    
                    ${build.description ? `
                    <div class="build-description">${build.description}</div>
                    ` : ''}
                    
                    <div class="build-actions">
                        <button class="btn btn-primary" onclick="addToCart(${build.id})"
                                ${build.stockQuantity === 0 ? 'disabled' : ''}>
                            <i class="fas fa-shopping-cart"></i>
                            ${build.stockQuantity === 0 ? 'Нет в наличии' : 'В корзину'}
                        </button>
                        <button class="btn btn-outline" onclick="showBuildDetails(${build.id})">
                            <i class="fas fa-info-circle"></i> Подробнее
                        </button>
                    </div>
                </div>
            </div>
        `;
    }).join('');
    
    container.innerHTML = buildsHTML;
}

// Рендеринг звезд рейтинга
function renderStars(rating) {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    let starsHTML = '';
    
    for (let i = 0; i < fullStars; i++) {
        starsHTML += '<i class="fas fa-star"></i>';
    }
    
    if (hasHalfStar) {
        starsHTML += '<i class="fas fa-star-half-alt"></i>';
    }
    
    const emptyStars = 5 - Math.ceil(rating);
    for (let i = 0; i < emptyStars; i++) {
        starsHTML += '<i class="far fa-star"></i>';
    }
    
    return starsHTML;
}

// Получение метки типа
function getTypeLabel(type) {
    const labels = {
        'gaming': 'Игровая сборка',
        'work': 'Рабочая станция',
        'budget': 'Бюджетная сборка'
    };
    return labels[type] || type;
}

// Рендеринг пагинации
function renderPagination() {
    const container = elements.pagination;
    
    if (state.totalPages <= 1) {
        container.innerHTML = '';
        return;
    }
    
    let paginationHTML = `
        <button class="page-btn" onclick="changePage(${state.filters.page - 1})" 
                ${state.filters.page <= 1 ? 'disabled' : ''}>
            <i class="fas fa-chevron-left"></i>
        </button>
    `;
    
    const startPage = Math.max(1, state.filters.page - 2);
    const endPage = Math.min(state.totalPages, state.filters.page + 2);
    
    for (let i = startPage; i <= endPage; i++) {
        paginationHTML += `
            <button class="page-btn ${i === state.filters.page ? 'active' : ''}" 
                    onclick="changePage(${i})">
                ${i}
            </button>
        `;
    }
    
    paginationHTML += `
        <button class="page-btn" onclick="changePage(${state.filters.page + 1})" 
                ${state.filters.page >= state.totalPages ? 'disabled' : ''}>
            <i class="fas fa-chevron-right"></i>
        </button>
    `;
    
    container.innerHTML = paginationHTML;
}

// Обновление статистики
function updateStats() {
    elements.totalCount.textContent = state.totalCount.toLocaleString('ru-RU');
}

// Инициализация событий
function initEvents() {
    // Поиск
    elements.searchBtn.addEventListener('click', () => {
        state.filters.search = elements.searchInput.value;
        state.filters.page = 1;
        loadBuilds();
    });
    
    elements.searchInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            state.filters.search = elements.searchInput.value;
            state.filters.page = 1;
            loadBuilds();
        }
    });
    
    // Типы
    elements.typeList.addEventListener('change', (e) => {
        if (e.target.name === 'type') {
            state.filters.type = e.target.value || null;
            state.filters.page = 1;
            loadBuilds();
        }
    });
    
    // Цена
    elements.minPrice.addEventListener('change', () => {
        const value = parseInt(elements.minPrice.value);
        if (!isNaN(value) && value >= 0) {
            state.filters.minPrice = value;
        }
    });
    
    elements.maxPrice.addEventListener('change', () => {
        const value = parseInt(elements.maxPrice.value);
        if (!isNaN(value) && value >= 0) {
            state.filters.maxPrice = value;
        }
    });
    
    elements.priceRange.addEventListener('input', () => {
        const value = parseInt(elements.priceRange.value);
        elements.maxPriceLabel.textContent = formatPrice(value);
        elements.maxPrice.value = value;
        state.filters.maxPrice = value;
    });
    
    // Сортировка
    elements.sortSelect.addEventListener('change', () => {
        state.filters.sortBy = elements.sortSelect.value;
        state.filters.page = 1;
        loadBuilds();
    });
    
    // Кнопки фильтров
    elements.applyFilters.addEventListener('click', () => {
        loadBuilds();
    });
    
    elements.resetFilters.addEventListener('click', () => {
        resetFilters();
        loadBuilds();
    });
    
    // Закрытие модального окна
    document.querySelectorAll('.close-modal').forEach(btn => {
        btn.addEventListener('click', () => {
            elements.buildModal.style.display = 'none';
        });
    });
    
    window.addEventListener('click', (e) => {
        if (e.target === elements.buildModal) {
            elements.buildModal.style.display = 'none';
        }
    });
}

// Сброс фильтров
function resetFilters() {
    state.filters = {
        type: null,
        minPrice: null,
        maxPrice: null,
        search: '',
        sortBy: 'popularity',
        page: 1,
        pageSize: 12
    };
    
    // Сбрасываем UI
    elements.searchInput.value = '';
    elements.minPrice.value = '';
    elements.maxPrice.value = '';
    elements.priceRange.value = 500000;
    elements.maxPriceLabel.textContent = '500 000 ₽';
    elements.sortSelect.value = 'popularity';
    
    renderTypes();
}

// Смена страницы
function changePage(page) {
    if (page < 1 || page > state.totalPages) return;
    state.filters.page = page;
    loadBuilds();
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// Показ деталей сборки
async function showBuildDetails(buildId) {
    try {
        const build = await fetchAPI(`${API_CONFIG.ENDPOINTS.BUILDS}/${buildId}`);
        
        // Исправляем путь к изображению
        let imageUrl = build.imageUrl || 'https://via.placeholder.com/600x400?text=No+Image';
        if (imageUrl.startsWith('../public/images/')) {
            imageUrl = imageUrl.replace('../public/images/', '');
        }
        
        const modalContent = `
            <div class="build-detail">
                <div class="build-detail-images">
                    <div class="main-image">
                        <img src="${imageUrl}" alt="${build.name}">
                    </div>
                </div>
                
                <div class="build-detail-info">
                    <div class="build-detail-header">
                        <span class="build-type">${getTypeLabel(build.type)}</span>
                        <h2>${build.name}</h2>
                        <div class="build-detail-specs">${build.specs || 'Характеристики не указаны'}</div>
                    </div>
                    
                    <div class="build-detail-price">${formatPrice(build.price)}</div>
                    
                    ${build.rating ? `
                    <div class="build-detail-rating">
                        <div class="stars">
                            ${renderStars(build.rating)}
                        </div>
                        <span class="review-count">${build.reviewCount || 0} отзывов</span>
                    </div>
                    ` : ''}
                    
                    <div class="build-detail-description">
                        <h4>Описание</h4>
                        <p>${build.description || 'Описание отсутствует'}</p>
                    </div>
                    
                    <div class="build-detail-actions">
                        <button class="btn btn-primary btn-large" onclick="addToCart(${build.id}); elements.buildModal.style.display='none';"
                                ${build.stockQuantity === 0 ? 'disabled' : ''}>
                            <i class="fas fa-shopping-cart"></i>
                            ${build.stockQuantity === 0 ? 'Нет в наличии' : 'Добавить в корзину'}
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        elements.buildModalContent.innerHTML = modalContent;
        elements.buildModal.style.display = 'flex';
    } catch (error) {
        console.error('Ошибка загрузки деталей сборки:', error);
        showNotification('Не удалось загрузить детали сборки', 'error');
    }
}

// Добавление в корзину
function addToCart(buildId) {
    const build = state.builds.find(b => b.id === buildId);
    
    if (!build) {
        showNotification('Ошибка: сборка не найдена', 'error');
        return;
    }
    
    if (build.stockQuantity === 0) {
        showNotification('Сборка отсутствует на складе', 'error');
        return;
    }
    
    // Получаем текущую корзину из localStorage
    let cartItems = JSON.parse(localStorage.getItem('cartItems') || '[]');
    
    // Проверяем, есть ли уже эта сборка в корзине
    const existingItem = cartItems.find(item => item.id === buildId && item.type === 'build');
    
    if (existingItem) {
        existingItem.quantity = (existingItem.quantity || 1) + 1;
    } else {
        cartItems.push({
            id: build.id,
            type: 'build',
            name: build.name,
            price: build.price,
            imageUrl: build.imageUrl,
            quantity: 1
        });
    }
    
    // Сохраняем в localStorage
    localStorage.setItem('cartItems', JSON.stringify(cartItems));
    
    // Обновляем счетчик
    updateCartCount();
    
    // Показываем уведомление
    showNotification(`"${build.name}" добавлена в корзину!`, 'success');
}

// Обновление счетчика корзины
function updateCartCount() {
    const cartItems = JSON.parse(localStorage.getItem('cartItems') || '[]');
    const totalCount = cartItems.reduce((sum, item) => sum + (item.quantity || 1), 0);
    localStorage.setItem('cartCount', totalCount);
    
    const cartCountElement = document.querySelector('.cart-count');
    if (cartCountElement) {
        cartCountElement.textContent = totalCount;
    }
}

// Показ уведомления
function showNotification(message, type = 'success') {
    const existing = document.querySelector('.notification');
    if (existing) {
        existing.remove();
    }
    
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
        <span>${message}</span>
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.classList.add('show');
    }, 10);
    
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Показ ошибки
function showError(message) {
    const errorDiv = document.createElement('div');
    errorDiv.className = 'error-message';
    errorDiv.innerHTML = `
        <i class="fas fa-exclamation-triangle"></i>
        <p>${message}</p>
    `;
    
    document.body.insertBefore(errorDiv, document.body.firstChild);
    
    setTimeout(() => {
        errorDiv.remove();
    }, 5000);
}

// Форматирование цены
function formatPrice(price) {
    return new Intl.NumberFormat('ru-RU', {
        style: 'currency',
        currency: 'RUB',
        minimumFractionDigits: 0
    }).format(price);
}
