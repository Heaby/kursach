// Состояние приложения
const state = {
    filters: {
        category: null,
        brand: null,
        minPrice: null,
        maxPrice: null,
        search: '',
        sortBy: 'popularity',
        page: 1,
        pageSize: 12
    },
    categories: [],
    brands: [],
    components: [],
    compareItems: [],
    totalCount: 0,
    totalPages: 1
};

// DOM элементы
const elements = {
    searchInput: document.getElementById('searchInput'),
    searchBtn: document.getElementById('searchBtn'),
    categoryList: document.getElementById('categoryList'),
    brandList: document.getElementById('brandList'),
    minPrice: document.getElementById('minPrice'),
    maxPrice: document.getElementById('maxPrice'),
    priceRange: document.getElementById('priceRange'),
    maxPriceLabel: document.getElementById('maxPriceLabel'),
    sortSelect: document.getElementById('sortSelect'),
    applyFilters: document.getElementById('applyFilters'),
    resetFilters: document.getElementById('resetFilters'),
    productsGrid: document.getElementById('productsGrid'),
    totalCount: document.getElementById('totalCount'),
    pagination: document.getElementById('pagination'),
    compareSlots: document.getElementById('compareSlots'),
    compareBtn: document.getElementById('compareBtn'),
    clearCompare: document.getElementById('clearCompare'),
    compareModal: document.getElementById('compareModal'),
    compareTable: document.getElementById('compareTable'),
    productModal: document.getElementById('productModal'),
    productModalContent: document.getElementById('productModalContent')
};

// Инициализация при загрузке страницы
document.addEventListener('DOMContentLoaded', async function() {
    console.log('Каталог: Инициализация...');
    
    try {
        // Загружаем категории и бренды
        await Promise.all([
            loadCategories(),
            loadBrands()
        ]);
        
        // Загружаем компоненты
        await loadComponents();
        
        // Инициализируем события
        initEvents();
        
        // Инициализируем сравнение из localStorage
        loadComparisonFromStorage();
        
        console.log('Каталог: Инициализация завершена');
    } catch (error) {
        console.error('Ошибка инициализации:', error);
        showError('Не удалось загрузить данные. Пожалуйста, обновите страницу.');
    }
});

// Загрузка категорий
async function loadCategories() {
    try {
        const categories = await fetchAPI(API_CONFIG.ENDPOINTS.CATEGORIES);
        state.categories = categories;
        renderCategories();
    } catch (error) {
        console.error('Ошибка загрузки категорий:', error);
    }
}

// Загрузка брендов
async function loadBrands() {
    try {
        const brands = await fetchAPI(API_CONFIG.ENDPOINTS.BRANDS);
        state.brands = brands;
        renderBrands();
    } catch (error) {
        console.error('Ошибка загрузки брендов:', error);
    }
}

// Загрузка компонентов
async function loadComponents() {
    try {
        elements.productsGrid.innerHTML = `
            <div class="loading-products">
                <div class="spinner"></div>
                <p>Загрузка товаров...</p>
            </div>
        `;
        
        // Формируем параметры запроса
        const params = {};
        if (state.filters.category) params.category = state.filters.category;
        if (state.filters.brand) params.brand = state.filters.brand;
        if (state.filters.minPrice) params.minPrice = state.filters.minPrice;
        if (state.filters.maxPrice) params.maxPrice = state.filters.maxPrice;
        if (state.filters.search) params.search = state.filters.search;
        if (state.filters.sortBy) params.sortBy = state.filters.sortBy;
        if (state.filters.page) params.page = state.filters.page;
        if (state.filters.pageSize) params.pageSize = state.filters.pageSize;
        
        const data = await fetchAPI(API_CONFIG.ENDPOINTS.COMPONENTS, params);
        
        // Сохраняем данные в состоянии
        state.components = data.data || [];
        state.totalCount = data.totalCount || 0;
        state.totalPages = data.totalPages || 1;
        
        // Обновляем UI
        renderComponents();
        renderPagination();
        updateStats();
        
    } catch (error) {
        console.error('Ошибка загрузки компонентов:', error);
        elements.productsGrid.innerHTML = `
            <div class="error-message">
                <i class="fas fa-exclamation-triangle"></i>
                <h3>Ошибка загрузки данных</h3>
                <p>Не удалось загрузить товары. Пожалуйста, попробуйте позже.</p>
                <button class="btn btn-primary" onclick="loadComponents()">
                    <i class="fas fa-redo"></i> Повторить попытку
                </button>
            </div>
        `;
    }
}

// Рендеринг категорий
function renderCategories() {
    const container = elements.categoryList;
    
    if (!state.categories || state.categories.length === 0) {
        container.innerHTML = '<div class="no-data">Категории не найдены</div>';
        return;
    }
    
    const categoriesHTML = state.categories.map(category => `
        <label class="category-item">
            <input type="radio" name="category" value="${category.name}" 
                   ${state.filters.category === category.name ? 'checked' : ''}>
            <span>${category.name}</span>
            <span class="category-count">(${category.componentCount || 0})</span>
        </label>
    `).join('');
    
    container.innerHTML = categoriesHTML + `
        <label class="category-item">
            <input type="radio" name="category" value="" ${!state.filters.category ? 'checked' : ''}>
            <span>Все категории</span>
        </label>
    `;
}

// Рендеринг брендов
function renderBrands() {
    const container = elements.brandList;
    
    if (!state.brands || state.brands.length === 0) {
        container.innerHTML = '<div class="no-data">Бренды не найдены</div>';
        return;
    }
    
    const brandsHTML = state.brands.map(brand => `
        <label class="brand-item">
            <input type="checkbox" name="brand" value="${brand}"
                   ${state.filters.brand === brand ? 'checked' : ''}>
            <span>${brand}</span>
        </label>
    `).join('');
    
    container.innerHTML = brandsHTML;
}

// Рендеринг компонентов
function renderComponents() {
    const container = elements.productsGrid;
    
    if (!state.components || state.components.length === 0) {
        container.innerHTML = `
            <div class="no-products">
                <i class="fas fa-search"></i>
                <h3>Товары не найдены</h3>
                <p>Попробуйте изменить параметры фильтрации</p>
            </div>
        `;
        return;
    }
    
    const componentsHTML = state.components.map(component => {
        // Определяем статус наличия
        let badgeClass = 'badge-outstock';
        let badgeText = 'Нет в наличии';
        
        if (component.stockQuantity > 10) {
            badgeClass = 'badge-instock';
            badgeText = 'В наличии';
        } else if (component.stockQuantity > 0) {
            badgeClass = 'badge-instock';
            badgeText = 'Мало';
        } else if (component.stockQuantity === 0) {
            badgeClass = 'badge-outstock';
            badgeText = 'Нет в наличии';
        }
        
        // Форматируем цену
        const formattedPrice = formatPrice(component.price);
        
        // Проверяем, есть ли товар в сравнении
        const isInComparison = state.compareItems.some(item => item.id === component.id);
        
        return `
            <div class="product-card" data-id="${component.id}">
                <div class="product-badge ${badgeClass}">${badgeText}</div>
                
                <div class="product-image" onclick="showProductDetails(${component.id})">
                    <img src="${component.imageUrl || 'https://via.placeholder.com/300x200?text=No+Image'}" 
                         alt="${component.name}"
                         onerror="this.src='https://via.placeholder.com/300x200?text=Image+Error'">
                </div>
                
                <div class="product-content">
                    <div class="product-category">${component.category?.name || 'Комплектующее'}</div>
                    <h3 class="product-title" onclick="showProductDetails(${component.id})">${component.name}</h3>
                    <div class="product-model">${component.model || 'Модель не указана'}</div>
                    
                    <div class="product-price">${formattedPrice}</div>
                    
                    <div class="product-rating">
                        <div class="stars">
                            ${renderStars(component.rating || 0)}
                        </div>
                        <span class="review-count">(${component.reviewCount || 0})</span>
                    </div>
                    
                    <div class="product-features">
                        <span class="feature-tag">${component.brand || 'Без бренда'}</span>
                        ${component.stockQuantity > 0 ? 
                          `<span class="feature-tag">${component.stockQuantity} шт.</span>` : ''}
                    </div>
                    
                    <div class="product-actions">
                        <button class="btn btn-compare ${isInComparison ? 'active' : ''}" 
                                onclick="toggleComparison(${component.id})">
                            <i class="fas fa-balance-scale"></i>
                            ${isInComparison ? 'В сравнении' : 'Сравнить'}
                        </button>
                        <button class="btn btn-primary" onclick="addToCart(${component.id})"
                                ${component.stockQuantity === 0 ? 'disabled' : ''}>
                            <i class="fas fa-shopping-cart"></i>
                            ${component.stockQuantity === 0 ? 'Нет в наличии' : 'В корзину'}
                        </button>
                    </div>
                </div>
            </div>
        `;
    }).join('');
    
    container.innerHTML = componentsHTML;
}

// Рендеринг звезд рейтинга
function renderStars(rating) {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
    
    let stars = '';
    
    for (let i = 0; i < fullStars; i++) {
        stars += '<i class="fas fa-star"></i>';
    }
    
    if (hasHalfStar) {
        stars += '<i class="fas fa-star-half-alt"></i>';
    }
    
    for (let i = 0; i < emptyStars; i++) {
        stars += '<i class="far fa-star"></i>';
    }
    
    return stars;
}

// Рендеринг пагинации
function renderPagination() {
    const container = elements.pagination;
    
    if (state.totalPages <= 1) {
        container.innerHTML = '';
        return;
    }
    
    let paginationHTML = '';
    
    // Кнопка "Назад"
    paginationHTML += `
        <button class="page-btn" onclick="changePage(${state.filters.page - 1})" 
                ${state.filters.page <= 1 ? 'disabled' : ''}>
            <i class="fas fa-chevron-left"></i>
        </button>
    `;
    
    // Номера страниц
    const startPage = Math.max(1, state.filters.page - 2);
    const endPage = Math.min(state.totalPages, startPage + 4);
    
    for (let i = startPage; i <= endPage; i++) {
        paginationHTML += `
            <button class="page-btn ${i === state.filters.page ? 'active' : ''}" 
                    onclick="changePage(${i})">
                ${i}
            </button>
        `;
    }
    
    // Кнопка "Вперед"
    paginationHTML += `
        <button class="page-btn" onclick="changePage(${state.filters.page + 1})" 
                ${state.filters.page >= state.totalPages ? 'disabled' : ''}>
            <i class="fas fa-chevron-right"></i>
        </button>
    `;
    
    container.innerHTML = paginationHTML;
}

// Обновление статистики
function updateStats() {
    elements.totalCount.textContent = state.totalCount.toLocaleString('ru-RU');
}

// Инициализация событий
function initEvents() {
    // Поиск
    elements.searchBtn.addEventListener('click', () => {
        state.filters.search = elements.searchInput.value;
        state.filters.page = 1;
        loadComponents();
    });
    
    elements.searchInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            state.filters.search = elements.searchInput.value;
            state.filters.page = 1;
            loadComponents();
        }
    });
    
    // Категории
    elements.categoryList.addEventListener('change', (e) => {
        if (e.target.name === 'category') {
            state.filters.category = e.target.value || null;
            state.filters.page = 1;
            loadComponents(); // Добавьте эту строку
        }
    });
    
    // Бренды
    elements.brandList.addEventListener('change', (e) => {
        if (e.target.name === 'brand') {
            state.filters.brand = e.target.checked ? e.target.value : null;
            state.filters.page = 1;
            loadComponents(); // Добавьте эту строку
        }
    });
    
    // Цена
    elements.minPrice.addEventListener('change', () => {
        const value = parseInt(elements.minPrice.value);
        if (!isNaN(value) && value >= 0) {
            state.filters.minPrice = value;
        }
    });
    
    elements.maxPrice.addEventListener('change', () => {
        const value = parseInt(elements.maxPrice.value);
        if (!isNaN(value) && value >= 0) {
            state.filters.maxPrice = value;
        }
    });
    
    elements.priceRange.addEventListener('input', () => {
        const value = parseInt(elements.priceRange.value);
        elements.maxPriceLabel.textContent = formatPrice(value);
        elements.maxPrice.value = value;
        state.filters.maxPrice = value;
    });
    
    // Сортировка
    elements.sortSelect.addEventListener('change', () => {
        state.filters.sortBy = elements.sortSelect.value;
        state.filters.page = 1;
        loadComponents();
    });
    
    // Кнопки фильтров
    elements.applyFilters.addEventListener('click', () => {
        loadComponents();
    });
    
    elements.resetFilters.addEventListener('click', () => {
        resetFilters();
        loadComponents();
    });
    
    // Сравнение
    elements.clearCompare.addEventListener('click', clearComparison);
    elements.compareBtn.addEventListener('click', showComparisonModal);
    
    // Закрытие модальных окон
    document.querySelectorAll('.close-modal').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.modal').forEach(modal => {
                modal.style.display = 'none';
            });
        });
    });
    
    window.addEventListener('click', (e) => {
        if (e.target.classList.contains('modal')) {
            e.target.style.display = 'none';
        }
    });
}

// Вспомогательные функции
function formatPrice(price) {
    return new Intl.NumberFormat('ru-RU', {
        style: 'currency',
        currency: 'RUB',
        minimumFractionDigits: 0
    }).format(price);
}

function showError(message) {
    const errorDiv = document.createElement('div');
    errorDiv.className = 'error-notification';
    errorDiv.innerHTML = `
        <i class="fas fa-exclamation-circle"></i>
        <span>${message}</span>
    `;
    errorDiv.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: #ef4444;
        color: white;
        padding: 15px 20px;
        border-radius: 8px;
        z-index: 10000;
        display: flex;
        align-items: center;
        gap: 10px;
        animation: slideIn 0.3s ease;
    `;
    
    document.body.appendChild(errorDiv);
    
    setTimeout(() => {
        errorDiv.remove();
    }, 5000);
}

function resetFilters() {
    state.filters = {
        category: null,
        brand: null,
        minPrice: null,
        maxPrice: null,
        search: '',
        sortBy: 'popularity',
        page: 1,
        pageSize: 12
    };
    
    // Сбрасываем UI
    elements.searchInput.value = '';
    elements.minPrice.value = '';
    elements.maxPrice.value = '';
    elements.priceRange.value = 1000000;
    elements.maxPriceLabel.textContent = '1 000 000 ₽';
    elements.sortSelect.value = 'popularity';
    
    renderCategories();
    renderBrands();
}

function changePage(page) {
    if (page < 1 || page > state.totalPages) return;
    
    state.filters.page = page;
    loadComponents();
    
    // Прокрутка к верху списка товаров
    elements.productsGrid.scrollIntoView({ behavior: 'smooth' });
}

// Функции для работы с корзиной (заглушка)
function addToCart(componentId) {
    const component = state.components.find(c => c.id === componentId);
    if (!component) return;
    
    // Логика добавления в корзину
    showNotification(`"${component.name}" добавлен в корзину!`);
    
    // Обновляем счетчик в корзине
    updateCartCount();
}

function updateCartCount() {
    // Логика обновления счетчика
    const cartCount = localStorage.getItem('cartCount') || 0;
    document.querySelector('.cart-count').textContent = cartCount;
}

function showNotification(message) {
    // Код для показа уведомления (аналогично главной странице)
    console.log('Notification:', message);
}

// Функции для работы со сравнением
async function toggleComparison(componentId) {
    const component = state.components.find(c => c.id === componentId);
    if (!component) return;
    
    const index = state.compareItems.findIndex(item => item.id === componentId);
    
    if (index === -1) {
        // Добавляем в сравнение
        if (state.compareItems.length >= 4) {
            showError('Максимум 4 товара для сравнения');
            return;
        }
        
        // Загружаем полные данные товара
        try {
            const fullComponent = await fetchAPI(`${API_CONFIG.ENDPOINTS.COMPONENTS}/${componentId}`);
            state.compareItems.push(fullComponent);
            saveComparisonToStorage();
            renderComparisonSlots();
            updateComparisonButton();
            renderComponents(); // Перерисовываем для обновления кнопок
        } catch (error) {
            console.error('Ошибка загрузки данных товара:', error);
        }
    } else {
        // Удаляем из сравнения
        state.compareItems.splice(index, 1);
        saveComparisonToStorage();
        renderComparisonSlots();
        updateComparisonButton();
        renderComponents(); // Перерисовываем для обновления кнопок
    }
}

function renderComparisonSlots() {
    const slots = elements.compareSlots.querySelectorAll('.compare-slot');
    
    slots.forEach((slot, index) => {
        const slotNumber = parseInt(slot.dataset.slot);
        const component = state.compareItems[index];
        
        slot.className = 'compare-slot';
        
        if (component) {
            slot.classList.add('filled');
            slot.innerHTML = `
                <button class="remove-compare" onclick="removeFromComparison(${component.id})">
                    <i class="fas fa-times"></i>
                </button>
                <div class="compare-slot-image">
                    <img src="${component.imageUrl || 'https://via.placeholder.com/50x50?text=No+Image'}" 
                         alt="${component.name}">
                </div>
                <span class="compare-slot-title">${component.name.substring(0, 20)}...</span>
                <span class="compare-slot-price">${formatPrice(component.price)}</span>
            `;
        } else {
            slot.classList.add('empty');
            slot.innerHTML = `
                <i class="fas fa-plus"></i>
                <span>Добавьте продукт</span>
            `;
            slot.onclick = () => {
                // Показываем подсказку
                showNotification('Выберите товар из списка и нажмите "Сравнить"');
            };
        }
    });
}

function removeFromComparison(componentId) {
    state.compareItems = state.compareItems.filter(item => item.id !== componentId);
    saveComparisonToStorage();
    renderComparisonSlots();
    updateComparisonButton();
    renderComponents();
}

function updateComparisonButton() {
    const count = state.compareItems.length;
    elements.compareBtn.textContent = `Сравнить (${count})`;
    elements.compareBtn.disabled = count < 2;
}

function loadComparisonFromStorage() {
    try {
        const saved = localStorage.getItem('compareItems');
        if (saved) {
            state.compareItems = JSON.parse(saved);
            renderComparisonSlots();
            updateComparisonButton();
        }
    } catch (error) {
        console.error('Ошибка загрузки сравнения из хранилища:', error);
    }
}

function saveComparisonToStorage() {
    try {
        localStorage.setItem('compareItems', JSON.stringify(state.compareItems));
    } catch (error) {
        console.error('Ошибка сохранения сравнения:', error);
    }
}

function clearComparison() {
    state.compareItems = [];
    saveComparisonToStorage();
    renderComparisonSlots();
    updateComparisonButton();
    renderComponents();
}

async function showComparisonModal() {
    if (state.compareItems.length < 2) {
        showError('Выберите хотя бы 2 товара для сравнения');
        return;
    }
    
    // Создаем таблицу сравнения
    const tableHTML = `
        <thead>
            <tr>
                <th>Характеристика</th>
                ${state.compareItems.map(component => `
                    <th class="compare-product-header">
                        <div class="compare-product-image">
                            <img src="${component.imageUrl || 'https://via.placeholder.com/100x100?text=No+Image'}" 
                                 alt="${component.name}">
                        </div>
                        <h4>${component.name}</h4>
                        <div class="compare-product-price">${formatPrice(component.price)}</div>
                        <button class="btn btn-small btn-outline" onclick="removeFromComparison(${component.id}); showComparisonModal();">
                            Удалить
                        </button>
                    </th>
                `).join('')}
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Бренд</td>
                ${state.compareItems.map(component => `<td>${component.brand || '-'}</td>`).join('')}
            </tr>
            <tr>
                <td>Модель</td>
                ${state.compareItems.map(component => `<td>${component.model || '-'}</td>`).join('')}
            </tr>
            <tr>
                <td>Категория</td>
                ${state.compareItems.map(component => `<td>${component.category?.name || '-'}</td>`).join('')}
            </tr>
            <tr>
                <td>Цена</td>
                ${state.compareItems.map(component => `<td>${formatPrice(component.price)}</td>`).join('')}
            </tr>
            <tr>
                <td>Наличие</td>
                ${state.compareItems.map(component => `
                    <td>${component.stockQuantity > 0 ? `${component.stockQuantity} шт.` : 'Нет в наличии'}</td>
                `).join('')}
            </tr>
            <tr>
                <td>Рейтинг</td>
                ${state.compareItems.map(component => `
                    <td>
                        ${renderStars(component.rating || 0)}
                        <br>
                        <small>(${component.reviewCount || 0} отзывов)</small>
                    </td>
                `).join('')}
            </tr>
            <tr>
                <td>Описание</td>
                ${state.compareItems.map(component => `<td>${component.description || '-'}</td>`).join('')}
            </tr>
        </tbody>
    `;
    
    elements.compareTable.innerHTML = tableHTML;
    elements.compareModal.style.display = 'flex';
}

async function showProductDetails(componentId) {
    try {
        const component = await fetchAPI(`${API_CONFIG.ENDPOINTS.COMPONENTS}/${componentId}`);
        
        const modalContent = `
            <div class="product-detail">
                <div class="product-detail-images">
                    <div class="main-image">
                        <img src="${component.imageUrl || 'https://via.placeholder.com/400x300?text=No+Image'}" 
                             alt="${component.name}">
                    </div>
                </div>
                
                <div class="product-detail-info">
                    <div class="product-detail-header">
                        <span class="product-category">${component.category?.name || 'Комплектующее'}</span>
                        <h2>${component.name}</h2>
                        <div class="product-model">${component.model || 'Модель не указана'}</div>
                    </div>
                    
                    <div class="product-detail-price">
                        <span class="price">${formatPrice(component.price)}</span>
                        ${component.stockQuantity > 0 ? 
                          `<span class="stock in-stock">В наличии (${component.stockQuantity} шт.)</span>` : 
                          `<span class="stock out-of-stock">Нет в наличии</span>`}
                    </div>
                    
                    <div class="product-detail-rating">
                        <div class="stars">
                            ${renderStars(component.rating || 0)}
                        </div>
                        <span class="review-count">${component.reviewCount || 0} отзывов</span>
                    </div>
                    
                    <div class="product-detail-description">
                        <h4>Описание</h4>
                        <p>${component.description || 'Описание отсутствует'}</p>
                    </div>
                    
                    <div class="product-detail-actions">
                        <button class="btn btn-compare ${state.compareItems.some(item => item.id === component.id) ? 'active' : ''}" 
                                onclick="toggleComparison(${component.id}); showProductDetails(${component.id});">
                            <i class="fas fa-balance-scale"></i>
                            ${state.compareItems.some(item => item.id === component.id) ? 'В сравнении' : 'Сравнить'}
                        </button>
                        <button class="btn btn-primary btn-large" onclick="addToCart(${component.id})"
                                ${component.stockQuantity === 0 ? 'disabled' : ''}>
                            <i class="fas fa-shopping-cart"></i>
                            ${component.stockQuantity === 0 ? 'Нет в наличии' : 'Добавить в корзину'}
                        </button>
                    </div>
                    
                    <div class="product-detail-specs">
                        <h4>Характеристики</h4>
                        <table class="specs-table">
                            <tr>
                                <td>Бренд</td>
                                <td>${component.brand || '-'}</td>
                            </tr>
                            <tr>
                                <td>Модель</td>
                                <td>${component.model || '-'}</td>
                            </tr>
                            <tr>
                                <td>Категория</td>
                                <td>${component.category?.name || '-'}</td>
                            </tr>
                            <tr>
                                <td>Наличие</td>
                                <td>${component.stockQuantity > 0 ? `${component.stockQuantity} шт.` : 'Нет в наличии'}</td>
                            </tr>
                            <tr>
                                <td>Дата добавления</td>
                                <td>${new Date(component.createdAt).toLocaleDateString('ru-RU')}</td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        `;
        
        elements.productModalContent.innerHTML = modalContent;
        elements.productModal.style.display = 'flex';
        
    } catch (error) {
        console.error('Ошибка загрузки деталей товара:', error);
        showError('Не удалось загрузить информацию о товаре');
    }
}