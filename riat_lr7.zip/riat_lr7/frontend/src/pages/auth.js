document.addEventListener('DOMContentLoaded', () => {
    const loginBtn = document.getElementById('loginBtn');
    if (!loginBtn) {
        return;
    }

    injectAuthModal();
    wireAuthEvents(loginBtn);
    applyLoginState(loginBtn);
    protectProfileLinks();
});

function injectAuthModal() {
    if (document.getElementById('authModal')) {
        return;
    }

    const modal = document.createElement('div');
    modal.className = 'modal auth-modal';
    modal.id = 'authModal';
    modal.innerHTML = `
        <div class="modal-content auth-modal__content">
            <span class="close-modal" id="closeAuthModal">&times;</span>
            <div class="auth-modal__header">
                <button class="auth-tab active" data-tab="login">Вход</button>
                <button class="auth-tab" data-tab="register">Регистрация</button>
            </div>
            <div class="auth-forms">
                <form id="loginForm" class="auth-form active">
                    <h3>Вход</h3>
                    <label>
                        Email
                        <input type="email" name="email" placeholder="you@example.com" required>
                    </label>
                    <label>
                        Пароль
                        <input type="password" name="password" placeholder="••••••••" required>
                    </label>
                    <button type="submit" class="btn btn-primary">Войти</button>
                    <p class="auth-status" id="loginStatus"></p>
                </form>
                <form id="registerForm" class="auth-form">
                    <h3>Регистрация</h3>
                    <label>
                        Имя
                        <input type="text" name="name" placeholder="Ваше имя" required>
                    </label>
                    <label>
                        Email
                        <input type="email" name="email" placeholder="you@example.com" required>
                    </label>
                    <label>
                        Пароль
                        <input type="password" name="password" placeholder="Минимум 6 символов" minlength="6" required>
                    </label>
                    <button type="submit" class="btn btn-primary">Зарегистрироваться</button>
                    <p class="auth-status" id="registerStatus"></p>
                </form>
            </div>
        </div>
    `;

    document.body.appendChild(modal);
}

function wireAuthEvents(loginBtn) {
    const modal = document.getElementById('authModal');
    const closeBtn = document.getElementById('closeAuthModal');
    const tabs = modal.querySelectorAll('.auth-tab');
    const forms = modal.querySelectorAll('.auth-form');
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');

    loginBtn.addEventListener('click', () => openAuthModal(modal, 'login'));
    closeBtn.addEventListener('click', () => closeAuthModal(modal));
    window.addEventListener('click', (event) => {
        if (event.target === modal) {
            closeAuthModal(modal);
        }
    });

    tabs.forEach(tab => {
        tab.addEventListener('click', () => switchTab(tab.dataset.tab, tabs, forms));
    });

    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        await handleLogin(new FormData(loginForm));
    });

    registerForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        await handleRegister(new FormData(registerForm));
    });
}

function switchTab(tabName, tabs, forms) {
    tabs.forEach(tab => tab.classList.toggle('active', tab.dataset.tab === tabName));
    forms.forEach(form => form.classList.toggle('active', form.id === `${tabName}Form`));
}

function openAuthModal(modal, tabName = 'login') {
    switchTab(tabName, modal.querySelectorAll('.auth-tab'), modal.querySelectorAll('.auth-form'));
    modal.style.display = 'flex';
}

function closeAuthModal(modal) {
    modal.style.display = 'none';
}

async function handleLogin(formData) {
    const status = document.getElementById('loginStatus');
    status.textContent = 'Проверяем...';
    status.classList.remove('error', 'success');

    const payload = {
        email: formData.get('email'),
        password: formData.get('password')
    };

    try {
        const response = await fetch(`${API_CONFIG.BASE_URL}${API_CONFIG.ENDPOINTS.AUTH_LOGIN}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data || 'Ошибка при входе');
        }

        status.textContent = 'Успешный вход!';
        status.classList.add('success');
        localStorage.setItem('participant', JSON.stringify(data.participant || data.Participant || {}));
        applyLoginState();
        setTimeout(() => closeAuthModal(document.getElementById('authModal')), 800);
    } catch (err) {
        status.textContent = err.message;
        status.classList.add('error');
    }
}

async function handleRegister(formData) {
    const status = document.getElementById('registerStatus');
    status.textContent = 'Регистрируем...';
    status.classList.remove('error', 'success');

    const payload = {
        name: formData.get('name'),
        email: formData.get('email'),
        password: formData.get('password')
    };

    try {
        const response = await fetch(`${API_CONFIG.BASE_URL}${API_CONFIG.ENDPOINTS.AUTH_REGISTER}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data || 'Ошибка при регистрации');
        }

        status.textContent = 'Регистрация успешно завершена! Теперь войдите.';
        status.classList.add('success');
        switchTab('login', document.querySelectorAll('.auth-tab'), document.querySelectorAll('.auth-form'));
    } catch (err) {
        status.textContent = err.message;
        status.classList.add('error');
    }
}

function applyLoginState(loginBtnOverride) {
    const loginBtn = loginBtnOverride || document.getElementById('loginBtn');
    if (!loginBtn) return;

    const participant = getStoredParticipant();
    if (participant && participant.email) {
        loginBtn.style.display = 'none';
    } else {
        loginBtn.style.display = 'inline-flex';
    }
}

function getStoredParticipant() {
    try {
        return JSON.parse(localStorage.getItem('participant') || 'null');
    } catch {
        return null;
    }
}

function protectProfileLinks() {
    const modal = document.getElementById('authModal');
    document.querySelectorAll('[data-profile-link]').forEach(link => {
        link.addEventListener('click', (e) => {
            const participant = getStoredParticipant();
            if (!participant || !participant.email) {
                e.preventDefault();
                if (modal) {
                    openAuthModal(modal, 'login');
                }
            }
        });
    });
}

// Глобальная функция выхода
function logoutUser() {
    localStorage.removeItem('participant');
    applyLoginState();
    window.location.href = 'index.html';
}

