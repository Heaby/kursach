document.addEventListener('DOMContentLoaded', () => {
    const participant = getParticipant();
    if (!participant) {
        alert('Авторизуйтесь, чтобы увидеть профиль');
        window.location.href = 'index.html';
        return;
    }

    fillProfile(participant);
    setupTabs();
    setupLogout();
});

function getParticipant() {
    try {
        return JSON.parse(localStorage.getItem('participant') || 'null');
    } catch {
        return null;
    }
}

function fillProfile(participant) {
    const name = participant.name || participant.Name || 'Пользователь';
    const email = participant.email || participant.Email || '';

    setText('profileName', name);
    setText('profileEmail', email);
    setValue('inputName', name);
    setValue('inputEmail', email);
}

function setText(id, value) {
    const el = document.getElementById(id);
    if (el) el.textContent = value;
}

function setValue(id, value) {
    const el = document.getElementById(id);
    if (el) el.value = value;
}

function setupTabs() {
    const tabs = document.querySelectorAll('.profile-tab');
    const sections = document.querySelectorAll('.profile-card');

    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const target = tab.dataset.tab;
            tabs.forEach(t => t.classList.toggle('active', t === tab));
            sections.forEach(sec => {
                sec.style.display = sec.id === `tab-${target}` ? 'block' : 'none';
            });
        });
    });
}

function setupLogout() {
    const btn = document.getElementById('logoutBtn');
    if (btn) {
        btn.addEventListener('click', () => {
            if (typeof logoutUser === 'function') {
                logoutUser();
            } else {
                localStorage.removeItem('participant');
                window.location.href = 'index.html';
            }
        });
    }
}

