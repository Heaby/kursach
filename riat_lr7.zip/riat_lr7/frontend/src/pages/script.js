// Данные популярных конфигураций с изображениями
const popularConfigs = [
    {
        id: 1,
        name: "Геймерская сборка Pro",
        type: "gaming",
        specs: "RTX 4080 • i9-13900K • 32GB DDR5 • 2TB SSD",
        price: 280000,
        description: "Для игр в 4K с максимальными настройками",
        image: "Selection (1).png",
        features: ["4K гейминг", "RGB подсветка", "Водяное охлаждение"]
    },
    {
        id: 2,
        name: "Офисный стандарт",
        type: "work",
        specs: "i5-13400 • 16GB DDR4 • 512GB SSD • Встроенная графика",
        price: 65000,
        description: "Надежный ПК для работы и учебы",
        image: "Selection (2).png",
        features: ["Тихая работа", "Энергоэффективность", "Wi-Fi/Bluetooth"]
    },
    {
        id: 3,
        name: "Рабочая станция Elite",
        type: "work",
        specs: "Ryzen 9 7950X • RTX 4090 • 64GB DDR5 • 4TB SSD",
        price: 450000,
        description: "Для профессионального монтажа и 3D-рендеринга",
        image: "Selection (4).png",
        features: ["3D рендеринг", "Видеомонтаж", "Профессиональная графика"]
    },
    {
        id: 4,
        name: "Стриминговая сборка",
        type: "gaming",
        specs: "Ryzen 7 7800X3D • RTX 4070 Ti • 32GB DDR5 • 2TB SSD",
        price: 220000,
        description: "Идеально для стриминга и контент-мейкинга",
        image: "Selection (3).png",
        features: ["Стриминг 4K", "Запись видео", "Высокий FPS"]
    },
    {
        id: 5,
        name: "Бюджетный вариант",
        type: "budget",
        specs: "Ryzen 5 5600 • RTX 3060 • 16GB DDR4 • 1TB SSD",
        price: 95000,
        description: "Отличное соотношение цены и производительности",
        image: "Selection (5).png",
        features: ["1080p гейминг", "Быстрый SSD", "Хорошее охлаждение"]
    },
    {
        id: 6,
        name: "Дизайнерский ПК Pro",
        type: "work",
        specs: "i7-14700K • RTX 4080 • 64GB DDR5 • 4TB SSD",
        price: 350000,
        description: "Для профессиональных дизайнеров и архитекторов",
        image: "Selection (6).png",
        features: ["Цветопередача 100% sRGB", "Быстрый рендеринг", "Множество портов"]
    }
];

// Функция форматирования цены
function formatPrice(price) {
    return price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ') + ' ₽';
}

// Функция получения текста для типа сборки
function getTypeText(type) {
    const types = {
        'gaming': 'Игровой',
        'work': 'Рабочий',
        'budget': 'Бюджетный'
    };
    return types[type] || type;
}

// Загрузка конфигураций на страницу
function loadConfigurations() {
    const container = document.getElementById('configsContainer');
    
    // Проверка существования контейнера
    if (!container) {
        console.error('Элемент configsContainer не найден!');
        document.getElementById('debug').textContent = 'Ошибка: configsContainer не найден';
        return;
    }
    
    console.log('Загрузка конфигураций...', popularConfigs.length);
    
    // Генерация HTML для каждой конфигурации
    const configsHTML = popularConfigs.map(config => `
        <div class="config-card">
            <div class="config-image">
                <img src="${config.image}" alt="${config.name}" 
                     onerror="this.src='https://images.unsplash.com/photo-1587202372634-32705e3bf49c?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80'">
            </div>
            <span class="config-type ${config.type}">
                ${getTypeText(config.type)}
            </span>
            <h3>${config.name}</h3>
            <p class="config-specs">${config.specs}</p>
            <p class="config-price">${formatPrice(config.price)}</p>
            <p class="config-description">${config.description}</p>
            <div class="config-features">
                ${config.features ? config.features.map(f => 
                    `<span class="feature-tag">${f}</span>`
                ).join('') : ''}
            </div>
            <div class="config-actions">
                <button class="btn btn-primary" onclick="selectConfig(${config.id})">
                    <i class="fas fa-shopping-cart"></i> Купить
                </button>
                <button class="btn btn-outline" onclick="viewDetails(${config.id})">
                    <i class="fas fa-info-circle"></i> Подробнее
                </button>
            </div>
        </div>
    `).join('');
    
    container.innerHTML = configsHTML;
    console.log('Конфигурации загружены');
}

// Обработчики событий
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM загружен, запускаем инициализацию...');
    
    // Загружаем конфигурации
    loadConfigurations();
    
    // Обновляем счетчик корзины
    updateCartCount();
    
    // Обработчики кнопок "Начать сборку"
    const startBtn = document.getElementById('startBuildBtn');
    const ctaBtn = document.getElementById('ctaBuildBtn');
    
    if (startBtn) {
        startBtn.addEventListener('click', openModal);
        console.log('Кнопка startBuildBtn найдена');
    } else {
        console.error('Кнопка startBuildBtn не найдена!');
    }
    
    if (ctaBtn) {
        ctaBtn.addEventListener('click', openModal);
        console.log('Кнопка ctaBuildBtn найдена');
    } else {
        console.error('Кнопка ctaBuildBtn не найдена!');
    }
    
    // Закрытие модального окна
    const closeBtn = document.querySelector('.close-modal');
    const confirmBtn = document.getElementById('confirmBuild');
    
    if (closeBtn) {
        closeBtn.addEventListener('click', closeModal);
    }
    
    if (confirmBtn) {
        confirmBtn.addEventListener('click', startCustomBuild);
    }
    
    // Закрытие модального окна при клике вне его
    window.addEventListener('click', function(event) {
        const modal = document.getElementById('startModal');
        if (event.target === modal) {
            closeModal();
        }
    });
    
    // Выбор типа сборки в модальном окне
    document.querySelectorAll('.build-option').forEach(option => {
        option.addEventListener('click', function() {
            document.querySelectorAll('.build-option').forEach(opt => {
                opt.classList.remove('active');
            });
            this.classList.add('active');
        });
    });
    
    // Мобильное меню
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    if (mobileMenuBtn) {
        mobileMenuBtn.addEventListener('click', toggleMobileMenu);
    }
    
    console.log('Инициализация завершена');
});

// Функции
function updateCartCount() {
    const cartCount = localStorage.getItem('cartCount') || 0;
    const cartCountElement = document.querySelector('.cart-count');
    if (cartCountElement) {
        cartCountElement.textContent = cartCount;
    }
}

function openModal() {
    const modal = document.getElementById('startModal');
    if (modal) {
        modal.style.display = 'flex';
    }
}

function closeModal() {
    const modal = document.getElementById('startModal');
    if (modal) {
        modal.style.display = 'none';
    }
}

function startCustomBuild() {
    const selectedOption = document.querySelector('.build-option.active');
    if (!selectedOption) {
        alert('Пожалуйста, выберите тип сборки');
        return;
    }
    
    const buildType = selectedOption.dataset.type;
    const buildTypeNames = {
        'gaming': 'игрового',
        'work': 'рабочего',
        'budget': 'бюджетного',
        'custom': 'индивидуального'
    };
    
    closeModal();
    
    // Показываем уведомление
    showNotification(`Запускаем конструктор для ${buildTypeNames[buildType]} ПК!`);
    
    // В реальном приложении:
    // window.location.href = `/constructor?type=${buildType}`;
}

function selectConfig(configId) {
    const config = popularConfigs.find(c => c.id === configId);
    
    if (!config) {
        console.error('Конфигурация не найдена:', configId);
        return;
    }
    
    // Добавляем в корзину
    let cartCount = parseInt(localStorage.getItem('cartCount') || 0);
    cartCount++;
    localStorage.setItem('cartCount', cartCount);
    updateCartCount();
    
    // Сохраняем выбранную конфигурацию
    let cartItems = JSON.parse(localStorage.getItem('cartItems') || '[]');
    cartItems.push(config);
    localStorage.setItem('cartItems', JSON.stringify(cartItems));
    
    // Показываем уведомление
    showNotification(`"${config.name}" добавлен в корзину!`);
    
    // Анимация кнопки
    const buttons = document.querySelectorAll(`button[onclick="selectConfig(${configId})"]`);
    buttons.forEach(btn => {
        btn.innerHTML = '<i class="fas fa-check"></i> В корзине';
        btn.classList.remove('btn-primary');
        btn.classList.add('btn-secondary');
        btn.disabled = true;
        
        setTimeout(() => {
            btn.innerHTML = '<i class="fas fa-shopping-cart"></i> Купить';
            btn.classList.remove('btn-secondary');
            btn.classList.add('btn-primary');
            btn.disabled = false;
        }, 2000);
    });
}

function viewDetails(configId) {
    const config = popularConfigs.find(c => c.id === configId);
    
    if (!config) {
        console.error('Конфигурация не найдена:', configId);
        return;
    }
    
    // Создаем модальное окно с деталями
    const modalHTML = `
        <div class="modal" id="detailModal" style="display: flex;">
            <div class="modal-content" style="max-width: 800px;">
                <span class="close-modal" onclick="closeDetailModal()">&times;</span>
                <div class="detail-container">
                    <div class="detail-image">
                        <img src="${config.image}" alt="${config.name}">
                    </div>
                    <div class="detail-info">
                        <span class="config-type ${config.type}">
                            ${getTypeText(config.type)}
                        </span>
                        <h2>${config.name}</h2>
                        <p class="detail-price">${formatPrice(config.price)}</p>
                        <p class="detail-specs"><strong>Характеристики:</strong> ${config.specs}</p>
                        <p class="detail-description">${config.description}</p>
                        <div class="detail-features">
                            <h4>Особенности:</h4>
                            <ul>
                                ${config.features.map(f => `<li>${f}</li>`).join('')}
                            </ul>
                        </div>
                        <button class="btn btn-primary btn-large" onclick="selectConfig(${config.id}); closeDetailModal();">
                            <i class="fas fa-shopping-cart"></i> Добавить в корзину
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // Добавляем модальное окно на страницу
    const modalContainer = document.createElement('div');
    modalContainer.innerHTML = modalHTML;
    document.body.appendChild(modalContainer);
    
    // Добавляем стили для детального просмотра
    const detailStyles = document.createElement('style');
    detailStyles.textContent = `
        .detail-container {
            display: flex;
            gap: 2rem;
            align-items: flex-start;
        }
        
        .detail-image {
            flex: 1;
            max-width: 400px;
        }
        
        .detail-image img {
            width: 100%;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
        }
        
        .detail-info {
            flex: 1;
        }
        
        .detail-price {
            font-size: 2rem;
            font-weight: 700;
            color: #0f172a;
            margin: 1rem 0;
        }
        
        .detail-specs {
            color: #475569;
            margin: 1rem 0;
            font-size: 1.1rem;
        }
        
        .detail-description {
            color: #64748b;
            margin: 1.5rem 0;
            line-height: 1.6;
        }
        
        .detail-features ul {
            list-style: none;
            margin: 1rem 0 2rem;
            padding: 0;
        }
        
        .detail-features li {
            padding: 0.5rem 0;
            color: #475569;
            border-bottom: 1px solid #e2e8f0;
        }
        
        .detail-features li:before {
            content: "✓";
            color: #10b981;
            margin-right: 10px;
            font-weight: bold;
        }
        
        .feature-tag {
            display: inline-block;
            background: #f1f5f9;
            color: #475569;
            padding: 0.3rem 0.8rem;
            border-radius: 20px;
            font-size: 0.85rem;
            margin-right: 0.5rem;
            margin-bottom: 0.5rem;
        }
        
        @media (max-width: 768px) {
            .detail-container {
                flex-direction: column;
            }
            
            .detail-image {
                max-width: 100%;
            }
        }
    `;
    document.head.appendChild(detailStyles);
}

function closeDetailModal() {
    const modal = document.getElementById('detailModal');
    if (modal) {
        modal.remove();
    }
}

function showNotification(message) {
    // Удаляем старые уведомления
    const oldNotifications = document.querySelectorAll('.notification');
    oldNotifications.forEach(n => n.remove());
    
    // Создаем новое уведомление
    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.innerHTML = `
        <i class="fas fa-check-circle"></i>
        <span>${message}</span>
    `;
    
    document.body.appendChild(notification);
    
    // Удаляем уведомление через 3 секунды
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

function toggleMobileMenu() {
    const navMenu = document.querySelector('.nav-menu');
    if (navMenu) {
        navMenu.style.display = navMenu.style.display === 'flex' ? 'none' : 'flex';
    }
}

// Добавляем обработчик ошибок загрузки изображений
window.addEventListener('error', function(e) {
    if (e.target.tagName === 'IMG') {
        console.warn('Ошибка загрузки изображения:', e.target.src);
        e.target.src = 'https://images.unsplash.com/photo-1587202372634-32705e3bf49c?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80';
        e.target.alt = 'Изображение временно недоступно';
    }
}, true);