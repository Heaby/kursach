// Конфигурация API
const API_CONFIG = {
    BASE_URL: 'http://localhost:5226/api', // URL вашего ASP.NET API
    ENDPOINTS: {
        COMPONENTS: '/components',
        CATEGORIES: '/components/categories',
        BRANDS: '/components/brands',
        BUILDS: '/builds',
        BUILD_TYPES: '/builds/types',
        AUTH_REGISTER: '/auth/register',
        AUTH_LOGIN: '/auth/login'
    }
};

// Функция для выполнения запросов к API
async function fetchAPI(endpoint, params = {}) {
    try {
        // Преобразуем параметры в query string
        const queryString = new URLSearchParams(params).toString();
        const url = `${API_CONFIG.BASE_URL}${endpoint}${queryString ? '?' + queryString : ''}`;
        
        console.log('Fetching:', url);
        
        const response = await fetch(url);
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        return await response.json();
    } catch (error) {
        console.error('API Error:', error);
        throw error;
    }
}
